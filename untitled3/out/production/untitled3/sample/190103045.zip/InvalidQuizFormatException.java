package sample;

class InvalidQuizFormatException extends Exception {
    public InvalidQuizFormatException(String var1) {
        super(var1);
    }
}