package sample;

public interface BotPlayer extends Player {
    void feed(Food f);
    void eat(Food f);
    void find();
}
